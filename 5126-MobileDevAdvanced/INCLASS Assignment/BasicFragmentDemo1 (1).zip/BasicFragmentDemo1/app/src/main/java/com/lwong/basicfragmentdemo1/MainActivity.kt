package com.lwong.basicfragmentdemo1

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    lateinit var tvMain: TextView
    lateinit var secondFragment: SecondFragment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        tvMain = findViewById<TextView>(R.id.tvMain)
    }

    fun receiveData(data:String) {
        tvMain.setText("Data received: $data")
 //       val tvSecond = findViewById<TextView>(R.id.tvSecond)
 //       tvSecond.setText(data)
        if(::secondFragment.isInitialized)
            secondFragment.setTextView(data)
    }

    fun onButtonClick(view: View) {
        when(view.id) {
            R.id.buttonAdd -> {
                secondFragment = SecondFragment()
                val transaction = supportFragmentManager.beginTransaction()
                transaction.add(R.id.fragmentContainerView2,secondFragment)
                transaction.addToBackStack("second")
                transaction.commit()
            }
            R.id.buttonRemove -> {
                val dynamicFragment = supportFragmentManager.findFragmentById(R.id.fragmentContainerView2)
                if(dynamicFragment != null) {
                    val transaction = supportFragmentManager.beginTransaction()
                    transaction.remove(dynamicFragment)
                    transaction.commit()
                }
            }
        }
    }
}