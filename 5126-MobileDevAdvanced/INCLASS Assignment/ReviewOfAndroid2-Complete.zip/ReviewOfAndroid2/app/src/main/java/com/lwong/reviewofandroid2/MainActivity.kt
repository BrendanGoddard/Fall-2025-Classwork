package com.lwong.reviewofandroid2

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.lwong.reviewofandroid2.databinding.ActivityMainBinding
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import kotlin.toString

class MainActivity : AppCompatActivity() {
    private lateinit var editText: EditText
    lateinit var binding: ActivityMainBinding

    // companion object is like static and can share between activities
    // object means singleton
    // access directly via the name of the containing class
    companion object {
        var nameS:String = ""
        var numS:Int = 1
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
 //       setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
       // editText = findViewById<EditText>(R.id.editTextName)
        val prefsEditor = getSharedPreferences("ReviewOfAndroid",MODE_PRIVATE)
        binding.editTextName.setText(prefsEditor.getString("NAME",""))
        binding.radioGroup.check(prefsEditor.getInt("NUM",R.id.radioButton1))
        when(binding.radioGroup.checkedRadioButtonId)
        {
            R.id.radioButton1 -> numS = 1
            R.id.radioButton2 -> numS = 2
            R.id.radioButton3 -> numS = 3
        }
        println("onCreate")
    }

    fun onButtonLogcat(view: View) {
        println(binding.editTextName.text.toString())
        val intent = Intent(this, ReportActivity::class.java).apply {
            putExtra("NAME",binding.editTextName.text.toString())
            var sel:Int = 1
            when(binding.radioGroup.checkedRadioButtonId){
                R.id.radioButton1 -> sel = 1
                R.id.radioButton2 -> sel = 2
                R.id.radioButton3 -> sel = 3
            }
            putExtra("NUM", sel)
        }
        startActivity(intent)
    }

    fun OnRadioClick(view: View) {
        when(view.id)
        {
            R.id.radioButton1 -> println("1")
            R.id.radioButton2 -> println("2")
            R.id.radioButton3 -> println("3")
        }
        var checked = binding.radioGroup.checkedRadioButtonId
        when(checked)
        {
            R.id.radioButton1 -> println("1")
            R.id.radioButton2 -> println("2")
            R.id.radioButton3 -> println("3")
        }
    }
    // Save the name to file
    fun onButtonSave(view: View?) {
        try {
            // to save to file "test.txt" in data/data/packagename/File
            val ofile = openFileOutput("test.txt", MODE_PRIVATE)
            val osw = OutputStreamWriter(ofile)
            osw.write(binding.editTextName.getText().toString())
            osw.flush()
            osw.close()
        } catch (ioe: IOException) {
            ioe.printStackTrace()
        }
    }

    // Read the name from file
    fun onButtonRead(view: View?) {
        // read the file from the data/data/packagename
        try {
            // reading from data/data/packagename/File
            val fin = openFileInput("test.txt")
            val isr = InputStreamReader(fin)
            val inputBuffer = CharArray(100)
            var str = ""
            var charRead: Int
            while ((isr.read(inputBuffer).also { charRead = it }) > 0) {
                val readString = String(inputBuffer, 0, charRead)
                str += readString
            }
            binding.editTextName.setText(str)
        } catch (ioe: IOException) {
            ioe.printStackTrace()
        }
    }

    override fun onPause() {
        super.onPause()
        val prefsEditor = getSharedPreferences("ReviewOfAndroid",MODE_PRIVATE).edit()
        prefsEditor.putString("NAME",binding.editTextName.text.toString())
        prefsEditor.putInt("NUM",binding.radioGroup.checkedRadioButtonId)
        prefsEditor.apply()
        println("onPause")
    }

    override fun onDestroy() {
        super.onDestroy()
        println("onDestroy")
    }

    override fun onStop() {
        super.onStop()
        println("onStop")
    }

    override fun onStart() {
        super.onStart()
        println("onStart")
    }

    override fun onResume() {
        super.onResume()
        when(numS)
        {
            1 -> binding.radioButton1.isChecked = true
            2 -> binding.radioButton2.isChecked = true
            3 -> binding.radioButton3.isChecked = true
        }
        println("onResume")
    }
}